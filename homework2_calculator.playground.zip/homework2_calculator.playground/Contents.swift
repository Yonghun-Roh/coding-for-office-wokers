//: Playground - noun: a place where people can play

import UIKit



class calculator {
    var num1:Int
    var num2:Int
    
    
    
    init(num1:Int , num2:Int){
        self.num1 = num1
        self.num2 = num2
        
    }
    
    func calculator() {
        print("\(num1) + \(num2)")
        print("\(num1) - \(num2)")
    
}
}

// 제 머리로는 여기까지네요.. var 7 var 3를 선언해서 먼가 해볼려고 했는데 생각해보니 숫자가 먼저 나오면 안되네요...위에도 제대로 코딩한건지 모르겠고요^^; 강의보고 컨닝하고 싶긴 하지만 일단 여기까지만하고 제출합니다..

var 7 = num1()
var 3 = num2()

