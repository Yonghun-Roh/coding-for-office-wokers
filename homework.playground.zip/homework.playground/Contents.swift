//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

var grade = 73

var A = 90
var B = 80
var C = 70
var D = 60
var E = 50
var F = 40


if grade >= A {
    print("A")
} else if A > grade && grade >= B  {
    print("B")
} else if B > grade && grade >= C  {
    print("C")
} else if C > grade && grade >= D  {
    print("D")
} else if D > grade && grade >= E  {
    print("E")
} else {
    print("F")
    


}



